# AWS-VPC-Landing-Zone-Terraform
AWS VPC Landing Zone Terraform Repo

### Architecture:

<img width="1044" alt="Screenshot 2024-04-12 at 9 25 27 PM" src="https://github.com/yeshwanthlm/AWS-VPC-Landing-Zone-Terraform/assets/66474973/27a6b686-e098-4b7a-bc1d-1a818b072daf">

